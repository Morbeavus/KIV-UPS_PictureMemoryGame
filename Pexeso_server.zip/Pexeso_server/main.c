#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <time.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <ifaddrs.h>
#include <pthread.h>
#include <unistd.h>

#include "player.h"
#include "game.h"

#define BUFF_LEN 70
#define CMD_LEN 4
#define GAME_SIZE 64



/*global variables*/
int sock, port;
int game_count;
int player_count;
socklen_t alen;
char *buff;
char *gmsg;
char last_packet_id = 0;
struct sockaddr_in sin1;
FILE *log_server, *fgames, *fplayers; /*FILES*/

pthread_t cmd_listener;
pthread_t  comm_pool[5];

struct player *players;
struct game *games;

/*global logging variables*/
time_t start_time, end_time; /* run-times */
int client_num, /* count of established connections */
games_played, /* count of played games */
recv_msg, recv_byte, /* count of received msgs and bytes */
sent_msg, sent_byte; /* count of sent msgs and bytes */

void server_logging_start(FILE *log_server)
{
	start_time = time( NULL );
	
	log_server = fopen( "server.log", "w" ); 
	
	fprintf( log_server, "Server startup time: %s", ctime( &start_time ));
	fprintf( log_server, "Server listening on port: %d.\n", port );
	fprintf( log_server, "_______________________________\n" );
	fclose( log_server );
}

void server_logging_end(FILE *log_server)
{
	end_time = time( NULL );
	int total_time = (int)difftime( end_time, start_time );
	
	log_server = fopen( "server.log", "a+" );
	fprintf( log_server, "Server end time: %s", ctime( &end_time ));
	fprintf( log_server, "Server runtime: %ds\n", total_time );
	fprintf( log_server, "_______________________\n" );
	fprintf( log_server, "Count of established connections: %d\n", client_num );
	fprintf( log_server, "Played games: %d\n", games_played );
	fprintf( log_server, "Received messeges: %d\n", recv_msg );
	fprintf( log_server, "Received bytes: %d\n", recv_byte );
	fprintf( log_server, "Sent messeges: %d\n", sent_msg );
	fprintf( log_server, "Sent bytes: %d\n", sent_byte );
	fclose( log_server );
}

int load_players(FILE *fplayers)
{
	int i;
	fplayers = fopen("players.txt","rb");
	if(!fplayers)
	{
		printf( "SERVER ERR#8: Failed to load players!\n" );
		return 8;
	}
	fread(&player_count, sizeof(int),1,fplayers);
	players = calloc(player_count, sizeof(struct player));
	fread(players, sizeof(struct player),player_count,fplayers);
	
	for(i = 0; i< player_count;i++)
	{
		players[i].addr = malloc(sizeof(struct sockaddr_in));
		fread(players[i].addr,sizeof(players[i].addr),1,fplayers);
	}
	
	printf("Loaded %d players \n",player_count)	;	
	fclose(fplayers);	
	return 0;
}
int save_players(FILE *fplayers)
{
	int i;
	fplayers = fopen("players.txt","wb");
	if(!fplayers)
	{
		printf( "SERVER ERR#9: Failed to save players!\n" );
		return 9;
	}
	fwrite(&player_count,sizeof(int),1,fplayers);
	fwrite(players, sizeof(struct player),player_count,fplayers);
	for(i = 0; i< player_count;i++)
	{
		fwrite(&players[i].addr,sizeof(struct sockaddr_in),1,fplayers);
	}
	
	
	printf("Saved %d players \n",player_count)	;
		
	fclose(fplayers);	
		
	return 0;
}

int load_games(FILE *fgames)
{
	
	fgames = fopen("games.txt","rb");
	if(!fgames)
	{
		printf( "SERVER ERR#6: Failed to load games!\n" );
		return 5;
	}
	fread(&game_count, sizeof(int),1,fgames);
	games = malloc(game_count * sizeof(struct game));
	fread(games, sizeof(struct game),game_count,fgames);
	
	printf("Loaded %d games \n",game_count)	;	
	fclose(fgames);	
	return 0;
}

int save_games(FILE *fgames)
{
	int i;
	int count = 0;
	fgames = fopen("games.txt","wb");
	if(!fgames)
	{
		printf( "SERVER ERR#7: Failed to save games!\n" );
		return 7;
	}
	for(i = 0; i < game_count; i++)
	{
		if(games[i].state != 3) count++;
	}
	
	fwrite(&count,sizeof(int),1,fgames);
	
	for(i = 0; i < game_count; i++)
	{
		if(games[i].state != 3) 
			fwrite(&games[i], sizeof(struct game),1,fgames);;
	}
	
	printf("Saved %d games \n",count);
		
	fclose(fgames);		
		
	return 0;
}

int exit_server()
{
	int i;
	printf("==========================\n");
	printf("Ending server\n");
	
	server_logging_end(log_server);
	printf("Freeing buffers\n");
	free(gmsg);
	free(buff);
	save_games(fgames);
	printf("Freeing games\n");
	free(games);
	save_players(fplayers);
	printf("Freeing players\n");
	for(i = 0; i< player_count; i++)
	{
		free(players[i].addr);
	}
	free(players);
	exit(0);
	return 0;
}
void print_server_addr()
{
	struct ifaddrs *addrs, *temp;
	
	getifaddrs(&addrs);
	temp = addrs;
	
	while ( temp ) 
	{
		if ( temp->ifa_addr && temp->ifa_addr->sa_family == AF_INET ) 
		{
			struct sockaddr_in *pAddr = (struct sockaddr_in *)temp->ifa_addr;
			if ( strcmp( temp->ifa_name, "lo" ) != 0 ) 
			{
				printf( "Server IP address: %s\n", inet_ntoa( pAddr->sin_addr ));
				break;
			}	
		}
		temp = temp->ifa_next;
	}
	freeifaddrs( addrs );
}
void *cmd_listen( void *arg ) {
	
	char command[CMD_LEN];
	
	while ( 1 ) {
		
		scanf( "%s", command );
		if ( strcmp( command, "exit" ) == 0 || strcmp( command, "quit" ) == 0 ) {
			
			exit_server();
		}
		else if ( strcmp( command, "help" ) == 0 ) {
			
			printf( "Server handling commands:\n" );
			printf( "\t\"help\" prints all usable commands\n" );
			printf( "\t\"exit\"|\"quit\"shuts down server\n" );
			printf( "\t\"save\" backups server resources\n" );
			printf( "\t\"players\" prints out registered players\n" );
		}
		else if ( strcmp( command, "save" ) == 0 ) 
		{
			
			printf( "Backingup:\n" );
			
			save_games(fgames);
			save_players(fplayers);
			
		}
		else if ( strcmp( command, "players" ) == 0 ) 
		{
			
			printf( "Registered players: \n" );
			int i;
			for(i = 0; i < player_count;i++)	
			{
				/*getting sender adress as string*/
				struct sockaddr_in* pV4Addr = players[i].addr; 
				int ipAddr = pV4Addr->sin_addr.s_addr;
				
				char sadr[INET_ADDRSTRLEN];
				inet_ntop(AF_INET, &ipAddr, sadr, INET_ADDRSTRLEN);
				/*getting sender port as string*/
				int port = (int)ntohs(players[i].addr->sin_port);
				
				printf("Player PID: %d is %s last known address: %s %d\n",players[i].ID,players[i].nick ,sadr,port);
			}		
		}
		else {
			
			printf( "Unknown command, use \"help\" for hints.\n" );
		}
	}
}

void *change_field_size(void *field, int cell_size, int field_size ) 
{
	
	void *temp;
	
	temp = realloc(field, (1 + field_size) * cell_size);
	if (!temp ) {
		
		printf("SERVER ERR#5: Out of memory!\n");
		
		free(field);
		exit(5);
	}
	
	return temp;
}
void new_game()
{
	int i;
	printf("Creating new game! \n");
	games = change_field_size(games, sizeof(struct game), game_count);
	
	games[game_count].ID = game_count; /*assign ID*/
	
	games[game_count].p_ID[0] = (buff[3]-'0');
	games[game_count].p_ID[1] = (-1);
	games[game_count].turning = 1;
	games[game_count].last_move = -1;
	games[game_count].last_move_c = 0;
	printf("PID: %d GID: %d \n",games[game_count].p_ID[0], games[game_count].ID);
	games[game_count].state = 0;
	
	for(i = 0; i < GAME_SIZE; i++)
	{
		games[game_count].cards[i] = buff[4 + i];
		/*printf("%c",games[game_count].cards[i]);*//*prints cards*/
		games[game_count].card_state[i] = 0;		
	}
	 
	game_count++;
}

void new_player(struct sockaddr_in sin, int nick_length, char *nick)
{
	
	
	printf("Registering new player: ");
	
	players = change_field_size(players, sizeof(struct player), player_count);
	
	players[player_count].lp_id = buff[0];
	
	players[player_count].addr = malloc(sizeof(struct sockaddr_in));
	
	memcpy(players[player_count].addr, &sin, sizeof(struct sockaddr_in) );
	
	players[player_count].nick_length = nick_length;
	strcpy(players[player_count].nick, nick);
	players[player_count].ID = player_count;
	
	printf("%s PID: %d\n",players[player_count].nick, (players[player_count].ID));
	player_count++;
	
	save_players(fplayers);
}

void send_msg(struct sockaddr_in* adress, char *msg) 
{
	int temp;
	
	/*getting sender adress as string*/
	struct sockaddr_in* pV4Addr = adress; 
	int ipAddr = pV4Addr->sin_addr.s_addr;
	
	char sadr[INET_ADDRSTRLEN];
	inet_ntop(AF_INET, &ipAddr, sadr, INET_ADDRSTRLEN);
	/*getting sender port as string*/
	int port = (int)ntohs(adress->sin_port);
	
	printf("SERVER: sending msg : |%s| ... to: %s port: %d\n", msg, sadr,port);
	
	temp = sendto( sock, msg, BUFF_LEN, 0,adress, 
		sizeof(struct sockaddr));
	
	if(temp < 0) 
	{
		
		printf("SERVER WARNING: Sending message failed.\n");
		perror("send to: ");
	}
	else
	{
		sent_msg++;
		sent_byte += temp;
	}
}

int make_move(char buff[])
{
	games[(int)(buff[4] - '0')].last_move = (int)(buff[3] - '0');
	games[(int)(buff[4] - '0')].last_move_c = (int)(buff[6] - '0');
	printf("turn counter--------%d----------%d\n",(buff[6] - '0'), games[buff[4] - '0'].last_move_c);
	
	return 0;
}

void *send_played_games( uint *arg ) 
{	
	uint temp = &arg[0];
	struct player host;
	
	int i, j;
	char play = '2';
	char lmsg[BUFF_LEN];
	
	for(i = 0; i < game_count; i++)
	{
		
		
		if(games[i].state == 0)
		{
			lmsg[0] = play; /*msg game ID*/
			play++;
			lmsg[1] = (char)games[i].ID +'0'; /*game ID(GID)*/
			host = players[games[i].p_ID[0]];
			int nick_length = host.nick_length-'0';
			
			for(j = 0; j < nick_length;j++)
			{
				lmsg[2 + j] = host.nick[j];/*copy nick*/
			}
			
			lmsg[3 + nick_length] = '\0';
			strcpy(gmsg, lmsg);
			usleep(500);
			send_msg(players[temp].addr,lmsg);
			memset(lmsg,0,BUFF_LEN);			
		}
	}
	
	return 0;
}


char get_played_games()
{
	char played = 0;
	int i;
	
	for(i = 0; i < game_count; i++)
	{
		if(games[i].state == 0)played++;
	}
	
	played+='0';
	
	return played;
}

int msg_handler(struct sockaddr_in sin, char *buff)
{
	int i = 0;
	int nick_l = (int)buff[3];
	char tnick [10];
	char temp [70];
	char temp2 [70];
	char buff_msg = buff[2];
	uint buff_PID = (uint)(buff[1]-'0');
	uint buff_GID = (uint)(buff[3]-'0');
	memset(temp,0,70);
	memset(temp2,0,70);
	temp[0] = buff[0];
	char hello[] = {buff[0],'H','e','l','l','o', '\0'};
		
	if(buff_msg == 'H')/*connection reset*/
	{	
		if(games[(uint)buff_GID].state != 3)
		{	
			send_msg(players[buff_PID].addr, hello);
		}
		else
		{
			temp[1] = 'E';
			temp[2] = '\0';
			 send_msg(players[buff_PID].addr, temp);
		}
	}
	else if(buff_msg == 't')/*give up his turn*/
	{
		games[buff_GID].turning = (buff[4]-'0');
		games[buff_GID].last_move = -1;
		games[buff_GID].last_move_c = 0;
		
		send_msg(players[buff_PID].addr, temp);
		
	}
	else if(buff_msg == 'M')/*did opponent move and how?*/
	{
		if(games[buff_GID].state != 3)
		{
			if(games[buff_GID].last_move != -1)
			{
				temp[1] = (char)(games[buff_GID].last_move + '0');
				temp[2] = '1';
				temp[3] = (char)(games[buff_GID].last_move_c + '0');
				temp[4] = '\0';
			}
			else
			{
				temp[1] = ('0' - 1);
				temp[2] = '0';
				temp[3] = '\0';
			}
		}
		else if(games[buff_GID].state == 3)
		{
			temp[1] = 'E';
			temp[2] = 'E';
			temp[3] = '\0';
		}
		
		send_msg(players[buff_PID].addr, temp);
	}
	else if(buff_msg == 's')/*sup did someone connected to my game?*/
	{
		if(games[(int)buff_GID].p_ID[1] != -1)
		{
			nick_l = players[games[(int)buff_GID].p_ID[1]].nick_length;
			temp[1] = (char)nick_l;
			printf("Opponent connecting: %s nick length: %d PID: %d \n",players[games[(int)buff_GID].p_ID[1]].nick, (nick_l - '0'), games[(int)buff_GID].p_ID[1]);
			for(i = 0; i < (nick_l - '0' + 1);i ++)
			{
				
				temp[2 + i] = players[games[(int)buff_GID].p_ID[1]].nick[i];
				tnick[i] = players[games[(int)buff_GID].p_ID[1]].nick[i];
			}
			
			tnick[1+i] = '\0';
			temp[1+i] = '\0';
			printf("Opponent connected: ");
			printf("%s|\n",tnick);
		}
		else
		{
			printf("no opponent yet\n");
			temp[1] = '\0';
		}
		
		send_msg(players[buff_PID].addr, temp);
	}
	else if(buff_msg == 'm') /*player move*/
	{
		make_move(buff);
		
		strcpy(temp, buff);
		send_msg(players[buff_PID].addr, temp);
		if(games[(uint)(buff[4]-'0')].p_ID[0] == buff_PID && games[(uint)(buff[4]-'0')].p_ID[1] !=-1)
		{
			send_msg(players[games[(uint)(buff[4]-'0')].p_ID[1]].addr, temp);
		}
		else if(games[(uint)(buff[4]-'0')].p_ID[1] == buff_PID && games[(uint)(buff[4]-'0')].p_ID[0] !=-1)
		send_msg(players[games[(uint)(buff[4]-'0')].p_ID[0]].addr, temp);	
	}
	else if(buff[1] == 'N')/*new player connecting*/
	{			
		for(i = 0; i < (nick_l);i++)
		{
			tnick[i] = buff[3+i];
		}	
		
		new_player(sin, (int)buff[2], tnick);
		temp[1] = (char) (player_count - 1 + '0');
		strcpy(gmsg, temp);
		send_msg(players[player_count-1].addr, temp);
	}
	else if(buff[1] == 'C')/*existing player connection*/
	{
 		memcpy(players[(uint)buff[2]-'0'].addr, &sin, sizeof(struct sockaddr_in) );
		/*getting sender adress as string*/
		struct sockaddr_in* pV4Addr = players[(uint)(buff[2]-'0')].addr; 
		int ipAddr = pV4Addr->sin_addr.s_addr;
	
		char sadr[INET_ADDRSTRLEN];
		inet_ntop(AF_INET, &ipAddr, sadr, INET_ADDRSTRLEN);
		
		/*getting sender port as decimal*/
		int port = (int)ntohs(players[(uint)(buff[2]-'0')].addr->sin_port);
		printf("Updated player adress: IP %s Port %d\n", sadr, port);
		
		strcpy(gmsg, temp);
		send_msg(players[(uint)(buff[2]-'0')].addr, temp);
	}
	else if(buff_msg == 'n')/*new game request*/
	{
		new_game();
		temp[1] = (char) (game_count - 1 + '0');
		strcpy(gmsg, temp);
		send_msg(players[buff_PID].addr, temp);
	}
	else if(buff_msg == 'r')/*lobby refresh request*/
	{
		temp[1] = get_played_games();
		strcpy(gmsg, temp);
		send_msg(players[buff_PID].addr, temp);
		
		pthread_create( &comm_pool[0], NULL, &send_played_games, buff_PID );
		
	}
	else if(buff_msg == 'j')/*Connection to existing game*/
	{
		
		/*printf("%d\n",(int)(buff[2]-'0'));*//*print game count*/
		games[(int)buff_GID].state = 1;
		games[(int)buff_GID].p_ID[1] = buff_PID;
		printf("Joined game state: %d Joining PID: %d buff_PID: %d\n",games[(int)buff_GID].state, games[(int)buff_GID].p_ID[1],buff_PID);
		
		for(i = 0; i < GAME_SIZE; i++)
		{
			temp[1+i] = games[(int)buff_GID].cards[i];
		}
				
		strcpy(gmsg, temp);
		send_msg(players[buff_PID].addr, temp);
		
		temp2[0] = '2';
		temp2[1] = 'j';
		
		nick_l = players[games[(int)buff_GID].p_ID[1]].nick_length;
		temp2[2] = (char)nick_l;
		printf("Opponent connecting: %s nick length: %d PID: %d \n",players[games[(int)buff_GID].p_ID[1]].nick, (nick_l - '0'), games[(int)buff_GID].p_ID[1]);
		for(i = 0; i < (nick_l - '0' + 1);i ++)
		{
			
			temp2[3 + i] = players[games[(int)buff_GID].p_ID[1]].nick[i];
			tnick[i] = players[games[(int)buff_GID].p_ID[1]].nick[i];
		}
		
		tnick[1+i] = '\0';
		temp2[3+i] = '\0';
		printf("Opponent connected: ");
		printf("%s|\n",tnick);
	
		send_msg(players[games[buff_GID].p_ID[0]].addr, temp2);
	}
	else if(buff_msg == 'i')/*info about state of cards*/
	{
		for(i = 0; i < GAME_SIZE; i++)
		{
			temp[1+i] = games[(int)buff_GID].card_state[i] + '0';
			
		}
				
		strcpy(gmsg, temp);
		send_msg(players[buff_PID].addr, temp);
	}
	else if(buff_msg == 'E')/*Connection to existing game*/
	{
		
		games[(int)buff_GID].state = 3;
		printf("GID %d state set to 3 = ended\n",(int)buff_GID);
		
		strcpy(gmsg, temp);
		temp[1] = 'E';
		temp2[0] = buff[0];
		temp2[1] = 'E';
		send_msg(players[buff_PID].addr, temp);
		if(games[buff_GID].p_ID[0] == buff_PID && games[buff_GID].p_ID[1] !=-1)
		{
			send_msg(players[games[buff_GID].p_ID[1]].addr, temp2);
		}
		else if(games[buff_GID].p_ID[1] == buff_PID && games[buff_GID].p_ID[0] !=-1)
		send_msg(players[games[buff_GID].p_ID[0]].addr, temp2);
		
	}
	return 0;
}




int main( int argc, const char* argv[] ) 
{
	/* variables */	
		
	/* checks arguments */
	if ( argc != 2 ) 
	{
		
		printf( "SERVER ERR#1: Missing agrument!\n" );
		printf( "Proper use: ./main <port number>\n" );
				
		return 1;
	}
		
	port = (int)strtol( argv[ 1 ], NULL, 10 );
	
	if ( port < 1024 || port > 65535 ) 
	{		
		printf( "SERVER ERR#2: Wrong port number!\n" );
		printf( "Enter port number between 1024 and 65535.\n" );
			
		return 2;
	}
	server_logging_start(log_server);
	load_games(fgames);
	load_players(fplayers);
	
	printf( "Server listens on port %d.\n", port );
	
	print_server_addr();		
	
	/* filling of sin struct */
	sin1.sin_family = AF_INET;
	sin1.sin_port = htons((u_short)port );
	sin1.sin_addr.s_addr = INADDR_ANY;
		
	/* alokate socket */
	if (( sock = socket( PF_INET, SOCK_DGRAM, IPPROTO_UDP )) < 0 ) 
	{
		printf( "SERVER ERR#3: Cannot allocate socket.\n" );
		perror("Socket allocation ");
		return( 3 );
	}
		
	/* bind socket */
	if ( bind( sock, (const struct sockaddr *)&sin1, sizeof( sin1 )) < 0 ) 
	{
		printf( "SERVER ERR#4: Cannot bind socket.\n" );
		perror("Socket bind ");
		return 4;
	}
	buff = malloc(BUFF_LEN * sizeof(char));
	gmsg = malloc(BUFF_LEN * sizeof(char));
	
	
	
	pthread_create( &cmd_listener, NULL, &cmd_listen, NULL );
	/*endless loop for comm*/
	while ( 1 ) 
	{
		/*wipes buffers*/
		memset(buff,0,BUFF_LEN);
		memset(gmsg,0,BUFF_LEN);
		
		/* receive msg */
		alen = sizeof( sin1 );
		
		recv_byte += recvfrom( sock, buff, BUFF_LEN, 0, (struct sockaddr *)&sin1, &alen );
		recv_msg++;
		
		/*getting sender adress as string*/
		struct sockaddr_in* pV4Addr = (struct sockaddr_in*)&sin1; 
		int ipAddr = pV4Addr->sin_addr.s_addr;
	
		char sadr[INET_ADDRSTRLEN];
		inet_ntop(AF_INET, &ipAddr, sadr, INET_ADDRSTRLEN);
		/*getting sender port as string*/
		int port = (int)ntohs(sin1.sin_port);
		printf("CLIENT: |%s| from: %s port: %d \n", buff, sadr,port);
			
		
		msg_handler(sin1,buff);
	}
}
