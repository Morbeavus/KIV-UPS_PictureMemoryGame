#ifndef _PLAYER_H
#define _PLAYER_H

struct player 
{
	int ID;
	char nick[10];
	int nick_length;
	char lp_id; /* last packet ID */
	struct sockaddr_in addr;/*player address*/
};

#endif
