#ifndef _GAME_H
#define _GAME_H

struct game 
{
	int ID;
	char cards[64];
	int card_state[64];
	int state; /* game state 0 waiting for player 1 in process 2 saved 3 done*/
	int turning; 
	int p_ID[2];
	int last_move;
	int last_move_c;
};

#endif
