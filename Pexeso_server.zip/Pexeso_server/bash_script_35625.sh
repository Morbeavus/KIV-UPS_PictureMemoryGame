#!/bin/bash

gcc -Wall -pthread  -c main.c
gcc -Wall -lpthread -o main main.c

chmod 777 main

./main 35625